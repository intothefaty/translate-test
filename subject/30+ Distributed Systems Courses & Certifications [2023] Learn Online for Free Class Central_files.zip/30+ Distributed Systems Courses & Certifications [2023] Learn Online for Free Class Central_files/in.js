// (☞ﾟ∀ﾟ)☞ static34
if( window._cgen ) {
_cgen.set_cookie('_jsuid', '1048025633');
_cgen.advanced();
_cgen.ping_start();
_cgen.set_cookie('_heatmaps_g2g_100717247', 'yes', 600 );
_heatmaps_g2g_100717247='yes';
}
